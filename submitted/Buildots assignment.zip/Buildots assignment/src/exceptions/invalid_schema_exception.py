class InvalidSchemaException(Exception):
    pass
